# ESLint Playground Fixture

This is an internal playground for quick iteration on our lint rules inside an IDE like VSCode.

See instructions in `./index.js` in this directory.

![Demo](https://duaw26jehqd4r.cloudfront.net/items/2Z390a31003O0l0o0e3O/Screen%20Recording%202019-01-16%20at%2010.29%20PM.gif?v=d6856125)